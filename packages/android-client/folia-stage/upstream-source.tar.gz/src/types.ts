import type { LucideIcon } from 'lucide-react';
import type { LineRenderHints } from './utils/lyrics/renderHints';
import type { LyricProviderSource } from './utils/lyrics/lyricSources';
import type { MediaId, OnlineProviderId, PlaybackSourceRef, ProviderCatalogRef } from './types/onlineMusic';

export interface LyricRuby {
  text: string;
  startTime: number; // Seconds
  endTime: number; // Seconds
}

export interface LyricSyllable {
  text: string;
  startTime: number; // Seconds
  endTime: number; // Seconds
  endsWithSpace?: boolean;
  ruby?: LyricRuby[];
  obscene?: boolean;
  emptyBeat?: number;
}

export interface LyricAlternateText {
  role: 'translation' | 'romanization' | string;
  language?: string;
  text: string;
  syllables?: LyricSyllable[];
}

export interface Word {
  text: string;
  startTime: number; // Seconds
  endTime: number; // Seconds
  syllables?: LyricSyllable[];
}

export interface LyricBackgroundVocal {
  text: string;
  startTime: number; // Seconds
  endTime: number; // Seconds
  words: Word[];
  agentId?: string;
  translation?: string;
  romanization?: string;
  alternateTexts?: LyricAlternateText[];
}

// 'both' stacks romanization above translation.
// Modes that lay translation out inside their own lyric layout (Monet, Pendolo, Lattice, Still) fall back to translation only.
// The shared bottom subtitle overlay does not read this: it has its own rows (SubtitleOverlayLayout).
export type SubtitleContentMode = 'translation' | 'romanization' | 'both' | 'none';

// One row of the shared bottom subtitle overlay: the line on screen, the line after it, or the line on screen's translation / romanization.
export type SubtitleOverlayRowSource = 'current' | 'next' | 'translation' | 'romanization';
export type SubtitleOverlayFollowRow = Exclude<SubtitleOverlayRowSource, 'current'>;
// The shared bottom subtitle overlay's rows, top to bottom, joined with '+'.
// The first row is the current line, its translation or its romanization (so a stack can leave the original text out);
// each row after it is the next line, the translation or the romanization.
export type SubtitleOverlayFirstRow = Exclude<SubtitleOverlayRowSource, 'next'>;
export type SubtitleOverlayRowsLayout =
  | SubtitleOverlayFirstRow
  | `${SubtitleOverlayFirstRow}+${SubtitleOverlayFollowRow}`
  | `${SubtitleOverlayFirstRow}+${SubtitleOverlayFollowRow}+${SubtitleOverlayFollowRow}`;
// A line the rows have nothing for (a translation row on a song without one) previews the coming lyrics instead.
// The '|only' ending turns that off: the overlay then shows its rows and nothing else.
// Stored and carried as this string.
export type SubtitleOverlayLayout = SubtitleOverlayRowsLayout | `${SubtitleOverlayRowsLayout}|only`;

export interface LyricAgent {
  id: string;
  name?: string;
  type?: string;
}

export interface Line {
  words: Word[];
  startTime: number;
  endTime: number;
  fullText: string;
  translation?: string;
  id?: string;
  agentId?: string;
  songPart?: string;
  blockIndex?: number;
  romanization?: string;
  alternateTexts?: LyricAlternateText[];
  backgroundVocal?: LyricBackgroundVocal;
  backgroundVocals?: LyricBackgroundVocal[];
  renderHints?: LineRenderHints;
  isChorus?: boolean;
  chorusEffect?: 'bars' | 'circles' | 'beams';
  // User-saved fine word boundaries for fullText, baked in upstream by the lyric setter.
  // join('') must equal fullText. When present it wins over every automatic segmentation.
  wordSegments?: string[];
  // icu-folia's automatic word boundaries for fullText (utils/lyrics/icuFolia), baked in by the
  // lyric setter once its engines have loaded. Used when there is no wordSegments; absent until
  // then, and the line falls back to plain Intl.Segmenter.
  autoWordSegments?: string[];
}

export interface LyricData {
  lines: Line[];
  title?: string;
  artist?: string;
  isWordByWord?: boolean;
  ttml?: {
    timingMode?: 'Word' | 'Line';
    agents?: Record<string, LyricAgent>;
  };
}

export interface Theme {
  name: string;
  backgroundColor: string;
  primaryColor: string;
  accentColor: string;
  secondaryColor: string;
  fontStyle: 'sans' | 'serif' | 'mono';
  fontFamily?: string;
  fontFamilyStack?: string[];
  fontWeight?: number;
  animationIntensity: 'calm' | 'normal' | 'chaotic';
  wordColors?: { word: string; color: string; }[];
  lyricsIcons?: string[];
  provider?: string;
  description?: string;
}

/**
 * 歌词自定义字体的来源。
 *
 * `market` 是字体市场（ZeoSeven）选的：它的 family 由运行时注入的 @font-face 提供，
 * 本机既没有字体文件、也不在系统字体表里，所以冷启动时必须按 fontId 重新登记一遍
 * （见 services/fontMarket.ts 的 restoreMarketFontChoice / fontMarket/zeosevenFont.ts）。
 */
export type CustomLyricsFontSource = 'system' | 'uploaded' | 'market';

export interface StoredCustomLyricsFont {
  source: CustomLyricsFontSource;
  family: string;
  label?: string | null;
  fontId?: string;
}

export interface DualTheme {
  light: Theme;
  dark: Theme;
}

export type ThemeMode = 'default' | 'ai' | 'custom';

export type BuiltinVisualizerMode = 'classic' | 'cadenza' | 'partita' | 'fume' | 'monet';
export type VisualizerMode = BuiltinVisualizerMode | (string & {});
export type VisualizerFrameRate = 'off' | 120 | 90 | 60 | 30;
/** 画布渲染分辨率的上下限，见 utils/renderPixelRatio.ts。 */
export type RenderPixelRatio = 0.5 | 0.75 | 1 | 1.25 | 1.5 | 2;

/**
 * 用 canvas / WebGL 画的歌词样式的渲染分辨率：相对样式自己默认像素密度（大多是屏幕的 devicePixelRatio，钳到 2）的倍数，
 * 大于 1 是超采样（utils/lyricRenderQuality.ts）。
 */
export type LyricRenderScale = 0.5 | 0.75 | 1 | 1.5 | 2;
/** 歌词画布的抗锯齿：auto 是各样式自己的默认（有的开 MSAA，有的靠后处理）。 */
export type LyricAntialias = 'auto' | 'on' | 'off';
/** 「动画与性能」里的全局挡位：各样式默认跟随它。 */
export interface LyricRenderQuality {
  scale: LyricRenderScale;
  antialias: LyricAntialias;
}
/** 一个歌词样式自己的分辨率与抗锯齿（存在样式的 tuning 里）：global 跟随全局挡位。 */
export interface LyricRenderOverride {
  scale: 'global' | LyricRenderScale;
  antialias: 'global' | 'on' | 'off';
}

export type HomeViewTab = 'playlist' | 'local' | 'albums' | 'navidrome' | 'radio' | 'cloud' | 'explore';

export type PlaybackContext = 'main' | 'stage';
export type StageSource = 'stage-api' | 'now-playing' | 'playercap';
export type StageLoopMode = 'off' | 'all' | 'one' | 'shuffle';
export type QueueAddBehavior = 'append' | 'next';
export type StageActiveEntryKind = 'lyrics' | 'media';

export interface StageEmbeddedUsltTag {
  language?: string;
  descriptor?: string;
  text: string;
}

export interface StageEmbeddedLyricSource {
  type: 'embedded';
  usltTags?: StageEmbeddedUsltTag[];
  textContent?: string;
  translationContent?: string;
}

export interface StageLocalLyricSource {
  type: 'local';
  lrcContent: string;
  tLrcContent?: string;
  formatHint?: 'lrc' | 'enhanced-lrc' | 'vtt' | 'ttml' | 'yrc' | 'qrc' | 'krc';
}

export interface StageNeteaseLyricBranch {
  lyric?: string;
  pureMusic?: boolean;
}

export interface StageNeteaseLyricSource {
  type: 'netease';
  lrc?: StageNeteaseLyricBranch & {
    yrc?: StageNeteaseLyricBranch;
    ytlrc?: StageNeteaseLyricBranch;
  };
  yrc?: StageNeteaseLyricBranch;
  ytlrc?: StageNeteaseLyricBranch;
  tlyric?: StageNeteaseLyricBranch;
  pureMusic?: boolean;
}

export interface StageNavidromeStructuredLyricLine {
  start?: number;
  value?: string;
}

export interface StageNavidromeLyricSource {
  type: 'navidrome';
  structuredLyrics?: StageNavidromeStructuredLyricLine[];
  plainLyrics?: string;
}

export interface StageQrcLyricSource {
  type: 'qrc';
  qrcContent: string;
  translationContent?: string;
}

export type StageLyricSource =
  | StageEmbeddedLyricSource
  | StageLocalLyricSource
  | StageNeteaseLyricSource
  | StageNavidromeLyricSource
  | StageQrcLyricSource;

/** Where an external player is, as last reported to the Stage API (POST /stage/lyrics or /stage/lyrics/clock). */
export interface StageLyricsClock {
  positionMs: number;
  paused: boolean;
  /** The main process's Date.now() when the position was received; the clock runs on from it. */
  sampledAtMs: number;
}

export interface StageLyricsSession {
  title?: string;
  artist?: string;
  album?: string;
  /** Absent for a session that only shows a track (its lyrics not found, or not here yet). */
  lyricSource?: StageLyricSource;
  durationMs?: number;
  coverUrl?: string;
  /** Present when an external player drives the session's time. */
  clock?: StageLyricsClock;
  updatedAt: number;
}

/** What POST /stage/lyrics/clock sends to the window: the clock of the session with that `updatedAt`. */
export interface StageLyricsClockUpdate {
  sessionUpdatedAt: number;
  clock: StageLyricsClock;
  durationMs?: number;
}

export interface StageMediaSession {
  id: string;
  title: string;
  artist: string;
  album?: string;
  durationMs?: number | null;
  coverUrl?: string | null;
  coverArtUrl?: string | null;
  audioUrl?: string | null;
  audioSrc: string;
  audioMimeType?: string;
  coverMimeType?: string;
  lyricsText?: string | null;
  lyricsFormat?: 'lrc' | 'enhanced-lrc' | 'vtt' | 'ttml' | 'yrc' | 'qrc' | null;
  updatedAt: number;
}

export type StageSession = StageMediaSession;

/** One song a Stage search found; `songRef` (`<provider>:<songId>`) plays or queues it. */
export interface StageSearchResult {
  songId: number | string;
  title: string;
  artists: string[];
  album: string;
  durationMs: number | null;
  coverUrl: string | null;
  provider: string;
  songRef: string;
}

/** A song the Stage API names: the omni provider and its id there. */
export interface StageSongRef {
  providerId: string;
  songId: number | string;
}

/** A search the Stage API asks the renderer to run at one omni provider. */
export interface StagePlayerSearchRequest {
  requestId: string;
  providerId: string;
  query: string;
  limit: number;
}

export interface StagePlayerSearchResult {
  requestId: string;
  ok: boolean;
  error?: string | null;
  songs?: StageSearchResult[];
}

export interface StageExternalPlayRequest extends StageSongRef {
  requestId: string;
  appendToQueue?: boolean;
}

export interface StageExternalPlayResult {
  requestId: string;
  ok: boolean;
  error?: string | null;
  baseSnapshot?: StagePlayerSnapshot;
  snapshot?: StagePlayerSnapshot;
  result?: unknown;
}

export interface StageStatus {
  domain?: 'stage-input';
  direction?: 'outside-in';
  enabled: boolean;
  modeEnabled?: boolean;
  source?: StageSource | null;
  port: number;
  token: string | null;
  activeEntryKind: StageActiveEntryKind | null;
  lyricsSession: StageLyricsSession | null;
  mediaSession: StageMediaSession | null;
}

export type StagePlayerPlaybackContext = 'normal-playback' | 'stage-session' | 'external-playback-source';

export interface StagePlayerCurrent {
  id: string;
  source: string;
  title: string;
  artist: string;
  album: string;
  durationMs: number;
  coverUrl: string | null;
}

export interface StagePlayerControlCapabilities {
  play: boolean;
  pause: boolean;
  resume: boolean;
  seek: boolean;
  previous: boolean;
  next: boolean;
}

export interface StagePlayerQueueCapabilities {
  append: boolean;
  insertNext: boolean;
  remove: boolean;
  move: boolean;
  select: boolean;
  clear: boolean;
}

export interface StagePlayerQueueItem extends StagePlayerCurrent {
  queueItemId: string;
}

export interface StagePlayerQueueSummary {
  currentIndex: number;
  length: number;
  revision?: string;
}

export interface StagePlayerQueueSnapshot extends StagePlayerQueueSummary {
  items: StagePlayerQueueItem[];
}

export interface StagePlayerQueueWindow extends StagePlayerQueueSummary {
  items: StagePlayerQueueItem[];
  offset: number;
  limit: number;
  returned: number;
  hasMore: boolean;
  nextOffset: number | null;
}

export type StagePlayerQueueDiffOp =
  | { op: 'insert'; index: number; item: StagePlayerQueueItem }
  | { op: 'remove'; index: number }
  | { op: 'move'; from: number; to: number }
  | { op: 'clear' }
  | { op: 'select'; index: number };

export interface StagePlayerQueueDiff {
  baseRevision: string;
  revision: string;
  ops: StagePlayerQueueDiffOp[];
  requiresReload?: true;
}

export interface StagePlayerSnapshot {
  playbackContext: StagePlayerPlaybackContext;
  current: StagePlayerCurrent | null;
  playerState: PlayerState;
  positionMs: number;
  durationMs: number;
  sampledAtMs: number;
  updatedAt: number;
  controlCapabilities: StagePlayerControlCapabilities;
  queueCapabilities: StagePlayerQueueCapabilities;
  queue: StagePlayerQueueSnapshot;
}

export interface StagePlayerControlRequest {
  requestId: string;
  action: 'next' | 'prev' | 'pause' | 'resume' | 'seek';
  positionMs?: number;
}

export interface StagePlayerQueueRequest {
  requestId: string;
  action: 'append' | 'insert-next' | 'remove' | 'move' | 'select' | 'clear';
  /** The songs an append or insert-next adds, in order. */
  songs?: StageSongRef[];
  queueItemId?: string;
  fromQueueItemId?: string;
  fromIndex?: number;
  toIndex?: number;
  index?: number;
}

export interface StagePlayerRequestResult {
  requestId: string;
  ok: boolean;
  error?: string | null;
  snapshot?: StagePlayerSnapshot;
  result?: unknown;
}

export type NowPlayingConnectionStatus = 'disabled' | 'connecting' | 'connected' | 'error';

export interface NowPlayingTrackSnapshot {
  id: string | null;
  title: string;
  artist: string;
  album: string;
  coverUrl: string | null;
  durationMs: number | null;
  isVideo?: boolean;
  isAdvertisement?: boolean;
}

export interface NowPlayingLyricPayload {
  source: string | null;
  title: string;
  artist: string;
  durationMs: number | null;
  hasLyric: boolean;
  hasTranslatedLyric: boolean;
  hasKaraokeLyric: boolean;
  lrc: string | null;
  translatedLyric: string | null;
  karaokeLyric: string | null;
}

export interface ClassicTuning {
  enableWordRotation: boolean;
  breathingFloatMultiplier: number;
  useLegacyLayout?: boolean;
  wordSpacing?: number;
  /** Space the words by how far they are drawn when scaled, turned and offset, so none overlaps another. */
  avoidOverlap?: boolean;
}

export const DEFAULT_CLASSIC_TUNING: ClassicTuning = {
  enableWordRotation: true,
  breathingFloatMultiplier: 1,
  useLegacyLayout: false,
  wordSpacing: 0.7,
  avoidOverlap: false,
};

export interface CadenzaTuning {
  /** 分辨率与抗锯齿（#929）：默认跟随「动画与性能」里的全局挡位（utils/lyricRenderQuality.ts）。 */
  render: LyricRenderOverride;
  fontScale: number;
  widthRatio: number;
  motionAmount: number;
  glowIntensity: number;
  beamIntensity: number;
}

export const DEFAULT_CADENZA_TUNING: CadenzaTuning = {
  render: { scale: 'global', antialias: 'global' },
  fontScale: 1.12,
  widthRatio: 0.72,
  motionAmount: 1,
  glowIntensity: 1,
  beamIntensity: 0,
};

export interface PartitaTuning {
  showGuideLines: boolean;
  useSemanticLayout: boolean;
  staggerMin: number;
  staggerMax: number;
  /** Space the words and rows by how far they are drawn when scaled, so none overlaps another. */
  avoidOverlap?: boolean;
}

export const DEFAULT_PARTITA_TUNING: PartitaTuning = {
  showGuideLines: true,
  useSemanticLayout: true,
  staggerMin: 20,
  staggerMax: 100,
  avoidOverlap: false,
};

export interface FumeTuning {
  /** 分辨率与抗锯齿（#929）：默认跟随「动画与性能」里的全局挡位（utils/lyricRenderQuality.ts）。 */
  render: LyricRenderOverride;
  hidePrintSymbols: boolean;
  disableGeometricBackground: boolean;
  backgroundObjectOpacity: number;
  textHoldRatio: number;
  cameraTrackingMode: 'stepped' | 'smooth';
  cameraSpeed: number;
  glowIntensity: number;
  heroScale: number;
}

export const DEFAULT_FUME_TUNING: FumeTuning = {
  render: { scale: 'global', antialias: 'global' },
  hidePrintSymbols: false,
  disableGeometricBackground: true,
  backgroundObjectOpacity: 0.5,
  textHoldRatio: 1,
  cameraTrackingMode: 'smooth',
  cameraSpeed: 1,
  glowIntensity: 1,
  heroScale: 1,
};

export interface CladdaghTuning {
  focusScaleRatio: number;
  radiusScale: number;
  ellipseTiltDeg: number;
  showAxisLine: boolean;
  /** 主歌词字符间距（px，每个字间隙额外加的量）。 */
  letterSpacingOffset: number;
  /** 圆环中心的左右位置（#1124）：相对画面宽度的百分比，0 是正中，正值往右。 */
  positionX?: number;
  /** 圆环中心的上下位置（#1124）：相对画面高度的百分比，0 是正中，正值往下。 */
  positionY?: number;
  /** 在每句主歌词下方沿圆环显示翻译（#1124）。 */
  showTranslation?: boolean;
  /** 翻译字号相对默认（主歌词的一半）的倍率。 */
  translationScale?: number;
  /** 翻译字符间距（px），同 letterSpacingOffset 的算法。 */
  translationLetterSpacingOffset?: number;
}

export const DEFAULT_CLADDAGH_TUNING: CladdaghTuning = {
  focusScaleRatio: 0.65,
  radiusScale: 1.0,
  ellipseTiltDeg: 45,
  showAxisLine: true,
  letterSpacingOffset: 0,
  positionX: 0,
  positionY: 0,
  showTranslation: false,
  translationScale: 1,
  translationLetterSpacingOffset: 0,
};

export type CappellaEmojiPackSource = 'builtin' | 'custom';
export type CappellaAvatarSource = 'cover' | 'builtin' | 'color' | 'custom';

export interface CappellaTuning {
  showEmoMessages: boolean;
  emojiPackSource: CappellaEmojiPackSource;
  avatarSource: CappellaAvatarSource;
}

export const DEFAULT_CAPPELLA_TUNING: CappellaTuning = {
  showEmoMessages: true,
  emojiPackSource: 'builtin',
  avatarSource: 'cover',
};

export type TiltColorScheme = 'default' | 'swap' | 'accentAll' | 'primaryAll';

export interface TiltTuning {
  splitProbability: number;
  tiltStyleProbability: number;
  colorScheme?: TiltColorScheme;
}

export const DEFAULT_TILT_TUNING: TiltTuning = {
  splitProbability: 0.75,
  tiltStyleProbability: 0.35,
  colorScheme: 'default',
};

export interface PendoloTuning {
  /** 分辨率与抗锯齿（#929）：默认跟随「动画与性能」里的全局挡位（utils/lyricRenderQuality.ts）。 */
  render: LyricRenderOverride;
  arcRadius: number;
  arcAngleDeg: number;
  wheelCenterX: number;
  wheelCenterY: number;
  tickSnappiness: number;
  activeScale: number;
  showGearDecor: 'none' | 'subtle' | 'full';
  showCenterGradient?: boolean;
  showCoverOnWatchFace?: boolean;
  enableLineGlow?: boolean;
  /** 歌词左右镜像（#1124）：表盘移到右边、歌词弧线在左；wheelCenterX 改从右边缘量。 */
  mirrorLayout?: boolean;
  /** 表盘倾斜（度，正值时倾斜轴上方往屏幕里退）：表盘平面带透视地转出屏幕，0 是平放。 */
  tiltDeg?: number;
  /** 倾斜轴的方向（度）：0 是水平轴（前后俯仰），±90 是竖直轴（左右偏转）。 */
  tiltAxisDeg?: number;
  /** 分层视差强度：倾斜时齿轮、摆轮、歌词按各自高度浮在表盘上方，0 是全在一个平面上。 */
  parallaxDepth?: number;
  /** 轮心视角：相机在轮心后上方、顺着刻度针看向焦点句，代替倾斜；只在 WebGL 下生效。 */
  hubView?: boolean;
  /** 轮心视角的相机高度（轮盘半径的倍数）：低时贴着表盘平视，高时接近俯视。 */
  hubViewHeight?: number;
  /** 轮心视角的相机从轮心沿刻度针反方向后退多远（轮盘半径的倍数），0 是正在轮心上方。 */
  hubViewBack?: number;
}

export const DEFAULT_PENDOLO_TUNING: PendoloTuning = {
  render: { scale: 'global', antialias: 'global' },
  arcRadius: 0.42,
  arcAngleDeg: 100,
  wheelCenterX: 0.0,
  wheelCenterY: 0.50,
  tickSnappiness: 2.0,
  activeScale: 1.25,
  showGearDecor: 'subtle',
  showCenterGradient: true,
  showCoverOnWatchFace: false,
  enableLineGlow: false,
  mirrorLayout: false,
  tiltDeg: 0,
  tiltAxisDeg: 0,
  parallaxDepth: 1,
  hubView: false,
  hubViewHeight: 1.4,
  hubViewBack: 1.2,
};

export type SonnetOuterFrameMode = 'none' | 'frame' | 'full';

export interface SonnetTuning {
  /** 分辨率与抗锯齿（#929）：默认跟随「动画与性能」里的全局挡位（utils/lyricRenderQuality.ts）。 */
  render: LyricRenderOverride;
  cameraIntensity: number;
  typographyMotion: number;
  mgDensity: number;
  showOnlyText: boolean;
  showGuide: boolean;
  showBackgroundMg: boolean;
  showFixedGeo: boolean;
  showGiantDecorativeText: boolean;
  showBackgroundDecor: boolean;
  enableTransitions: boolean;
  outerFrameMode: SonnetOuterFrameMode;
  textureResolution: number;
  /** Master switch for the scene-wide post-process stack (grain + contrast). */
  postProcessEnabled: boolean;
  /** Film grain amount, 0..1. */
  postProcessGrain: number;
  /** Contrast boost, 0..1. */
  postProcessContrast: number;
  /** Fixed print-style passes riding the master switch; strength sliders, 0 disables the pass. */
  postProcessRgbShift: number;
  postProcessHalftone: number;
  /** Vignette strength, 0..2 (2 = double the base darkening). */
  postProcessVignette: number;
  /** Radial lens curvature amount, 0..2. */
  postProcessLensDistortion: number;
  /** Radial chromatic dispersion amount, 0..1. */
  postProcessLensDispersion: number;
}

/**
 * 商籁（sonnet）镜头运动强度的上限 —— 也是它的默认值。
 *
 * 这一档的相机运动是叠在分镜与转场上的：数值再高，镜头推拉很容易把画面甩出屏幕外（画幅
 * 边缘露黑、歌词被推出画面）。所以「能调多少」就定在 0.7，默认也直接落在 0.7 —— 默认即
 * 安全上限，滑块只能往下收。
 *
 * 改这里一处即可：AI 导演的可调范围（services/lyricDirector/catalog）、store 的写入夹取、
 * 读取 localStorage 时的旧数据兼容、外观码导入，全都引这个常量。
 * 凝彩（tempera）的 cameraIntensity 是另一回事，不受它约束。
 */
export const SONNET_CAMERA_INTENSITY_MAX = 0.7;

export const DEFAULT_SONNET_TUNING: SonnetTuning = {
  render: { scale: 'global', antialias: 'global' },
  // dev 的默认即安全上限（见上面 SONNET_CAMERA_INTENSITY_MAX 的说明）：合并 v0.7.26 时
  // 这里一度被上游的 1 覆盖，那会直接越过夹取上限，所以按 dev 取常量。
  cameraIntensity: SONNET_CAMERA_INTENSITY_MAX,
  typographyMotion: 1,
  mgDensity: 1,
  showOnlyText: false,
  showGuide: true,
  showBackgroundMg: true,
  showFixedGeo: true,
  showGiantDecorativeText: true,
  showBackgroundDecor: true,
  enableTransitions: true,
  outerFrameMode: 'full',
  textureResolution: 1.5,
  postProcessEnabled: false,
  postProcessGrain: 0.2,
  postProcessContrast: 0,
  postProcessRgbShift: 0,
  postProcessHalftone: 0,
  postProcessVignette: 0.85,
  postProcessLensDistortion: 0.3,
  postProcessLensDispersion: 0.6,
};

/**
 * One beat effect's own setting under 智能动感模式 (services/beatFx/beatEffects.ts): whether it plays,
 * and its strength, 0..2, 1 being the look it was tuned to.
 */
export interface BeatEffectSetting {
  on: boolean;
  strength: number;
  /**
   * An effect made of parts, each with its own slider (BeatEffectDef `parts`, 雾笺's 疏雨轻车): their
   * strengths by part key, 0..2, a part never touched at 1. `strength` is then unused.
   */
  parts?: Record<string, number>;
}

/**
 * 智能动感模式's three settings (2026-10-17, the user's 全开 / 半开 / 不开):
 * - `on`: the effects play, and a track with nothing stored is analysed now on the GPU.
 * - `cached`: the effects play from what is already stored - a track analysed before under `on`, or
 *   whose beats automix analysed - and nothing is ever started for them: no model run, no decode, no
 *   stream read. A track with nothing stored keeps its original picture. Runs already in flight
 *   elsewhere (automix's) are waited for and used, as they cost nothing more. Automix itself is not
 *   changed by this setting.
 * - `off`: every picture exactly as it was; nothing read, nothing run.
 */
export type SmartBeatMode = 'off' | 'cached' | 'on';

/**
 * 智能动感模式, one setting for every visualizer and background that draws beat FX, and each effect's
 * own setting. The effects a picture has are declared on its registry entry (`beatEffects`), each
 * reading beat_this' beats or htdemucs' drum hits (src/services/beatFx). An effect with nothing
 * stored plays at strength 1. Read `mode` through `smartBeatActive` / `smartBeatMayAnalyse`
 * (services/beatFx/beatEffects.ts), never by comparing it in place.
 */
export interface SmartBeatSettings {
  mode: SmartBeatMode;
  /** Keyed by effect id (`sonnet.lensTear`); only the effects the user has touched. */
  effects: Readonly<Record<string, BeatEffectSetting>>;
}

export const DEFAULT_SMART_BEAT_SETTINGS: SmartBeatSettings = {
  mode: 'off',
  effects: {},
};

/**
 * `gradient` fills every tone shape with a four-colour ramp built from the cover art's
 * extracted colours mixed with the theme, instead of a flat tone.
 */
export type TemperaColorMode = 'duo' | 'mono' | 'gradient';

/** Where an image tends to sit; the exact spot is picked per shot from the seed. */
export type TemperaLayerImageAlign = 'left' | 'center' | 'right' | 'free';

/** Vertical counterpart to `TemperaLayerImageAlign`; `free` lets each shot choose a band. */
export type TemperaLayerImageVerticalAlign = 'top' | 'center' | 'bottom' | 'free';

/**
 * One image in the user's Tempera pool - character art, a logo, a texture. Each shot picks one
 * of them and places it itself, so an image carries a *tendency* rather than coordinates:
 * hand-placing every picture would defeat the point of a pool. The file itself sits in
 * IndexedDB under the same `id`, keeping the tuning small enough to sync.
 */
export interface TemperaLayerImage {
  id: string;
  name: string;
  align: TemperaLayerImageAlign;
  verticalAlign: TemperaLayerImageVerticalAlign;
  /** Height as a fraction of the viewport height; width follows the source aspect. */
  scale: number;
  opacity: number;
}

export const TEMPERA_MAX_LAYER_IMAGES = 16;

export const DEFAULT_TEMPERA_LAYER_IMAGE: Omit<TemperaLayerImage, 'id' | 'name'> = {
  align: 'free',
  // Preserve the original character-art composition, which placed images low in the frame.
  verticalAlign: 'bottom',
  scale: 0.7,
  opacity: 1,
};

export interface TemperaTuning {
  /** 分辨率与抗锯齿（#929）：默认跟随「动画与性能」里的全局挡位（utils/lyricRenderQuality.ts）。 */
  render: LyricRenderOverride;
  cameraIntensity: number;
  /** Per-glyph entrance motion strength, 0..2. */
  glyphMotion: number;
  /** Keep each source lyric line in one shot instead of slicing it into half-phrases. */
  wholeLineLyrics: boolean;
  /**
   * 逐字入场时序, 0..1. How much of the way to the shot's lyric end each glyph's entrance
   * stretches, past its 0.34s floor. 0 gives every glyph the same short window - percussive,
   * and the shot is fully at rest well before it cuts. 1 lands the whole shot exactly on its
   * lyric end - continuous, but nothing is ever still. See temperaLayout for the measurements.
   */
  glyphSettleStretch: number;
  /** 墨染奥行 景深, 0..2: the depth blur and the layers' parallax. Only while 墨染奥行 is on. */
  depthOfField: number;
  /** 墨染奥行 镜头平移, 0..2: how far each shot slides in and drifts. Only while 墨染奥行 is on. */
  depthPan: number;
  /** 墨染奥行 歌词远近, 0..2: how far small glyphs fade back and big ones lead. Only while 墨染奥行 is on. */
  glyphDepth: number;
  /** duo derives blocks from theme hues; mono collapses to a grayscale ink/paper ladder. */
  colorMode: TemperaColorMode;
  showBlocks: boolean;
  showDecor: boolean;
  /** 边角线框: the two registration marks in the top-left and bottom-right corners. */
  showCornerMarks: boolean;
  /**
   * 文字动态反色: the lyric samples the artwork under it and picks whichever of ink/paper
   * contrasts more, per pixel. This is how the mode colours type, not a post-process, so it
   * has its own switch rather than riding `postProcessEnabled`.
   */
  textInversion: boolean;
  /** Pool of user images; each shot picks one. The files themselves live in IndexedDB. */
  layerImages: TemperaLayerImage[];
  /** `back` lets the lyric invert against the picture; `front` puts it over the lyric. */
  layerImageDepth: 'back' | 'front';
  /** 0..1 chance that a given shot shows an image at all. */
  layerImageFrequency: number;
  enableTransitions: boolean;
  textureResolution: number;
  /** Master switch for the scene-wide post-process stack (grain + contrast + print passes). */
  postProcessEnabled: boolean;
  /**
   * 后处理纹理压缩: renders the post-process pass at 1x and stretches it onto the canvas
   * instead of running it at `textureResolution`. Costs sharpness on hatch, screentone and
   * type; buys back the fill rate a full-resolution full-screen pass costs.
   */
  postProcessTextureCompression: boolean;
  /** Film grain amount, 0..1. */
  postProcessGrain: number;
  /** Contrast boost, 0..1. */
  postProcessContrast: number;
  /** RGB shift pass strength, 0..1 (0 disables the pass). */
  postProcessRgbShift: number;
  /** Vignette strength, 0..2 (2 = double the base darkening). */
  postProcessVignette: number;
  /** Radial lens curvature amount, 0..2. */
  postProcessLensDistortion: number;
}

export const DEFAULT_TEMPERA_TUNING: TemperaTuning = {
  render: { scale: 'global', antialias: 'global' },
  cameraIntensity: 1,
  glyphMotion: 1,
  wholeLineLyrics: false,
  glyphSettleStretch: 0.5,
  depthOfField: 1,
  depthPan: 1,
  glyphDepth: 1,
  colorMode: 'duo',
  showBlocks: true,
  showDecor: true,
  showCornerMarks: true,
  textInversion: true,
  layerImages: [],
  layerImageDepth: 'back',
  layerImageFrequency: 0.6,
  enableTransitions: true,
  textureResolution: 1.5,
  postProcessEnabled: true,
  postProcessTextureCompression: false,
  postProcessGrain: 0.2,
  postProcessContrast: 0,
  postProcessRgbShift: 0,
  postProcessVignette: 0.85,
  postProcessLensDistortion: 0.3,
};

/**
 * 绘光画质档位。`full` 全分辨率；`balanced` / `low` 把光场与辉光降采样、烟雾倍频数封顶，用于省电。
 */
export type LumiereRenderQuality = 'full' | 'balanced' | 'low';

export interface LumiereTuning {
  /** 分辨率与抗锯齿（#929）：默认跟随「动画与性能」里的全局挡位（utils/lyricRenderQuality.ts）。 */
  render: LyricRenderOverride;
  /** 光强倍率, 0.3..2. */
  lightIntensity: number;
  /** 随音乐变亮, 0..2 (0 = 不随音乐变). */
  audioResponse: number;
  /** 烟雾浓度, 0..2. */
  fogDensity: number;
  /**
   * 暗场强度, 0..1：光后面铺一层主题背景色压暗的底，压住 folia 的共享背景（0 = 共享背景原样透出）。
   * 浅色主题保底 0.94（绘光始终在暗场里）。
   */
  darkField: number;
  /** 浮尘数量, 0..2. */
  moteAmount: number;
  /** 图形辉光, 0..2. */
  bloom: number;
  /** 文字辉光, 0..2. */
  textBloom: number;
  /** 未唱字透明度, 0.05..0.6. */
  unlitOpacity: number;
  /** 邻行：1 = 上一行 + 当前行，2 = 上一行 + 当前行 + 下一行. */
  windowNeighbors: 1 | 2;
  /** 崩解强度, 0..2. */
  decay: number;
  /** 背景歌词亮度, 0..2 (0 = 关). */
  echo: number;
  /** 烟雾细节（倍频数）, integer 2..6. */
  fogOctaves: number;
  /** 线稿. */
  lineArt: boolean;
  /** 前景散景. */
  frontBokeh: boolean;
  /** 所有换位都走轨迹线. */
  trails: boolean;
  /** 隐藏所有歌词换位的轨迹线，保留字的飞行与轨迹过渡. */
  hideTrails: boolean;
  /**
   * 轨迹过渡：段落之间也和段内换镜头一样在同一个光场里交接（整首歌编成一个场景单元），
   * 没有熄灯 / 闪白 / 拉焦 / 交叉渐变。改它会重新编译程序.
   */
  seamlessTransitions: boolean;
  /** 画框. */
  overlayFrame: boolean;
  /**
   * 仅显示歌词文字：只画歌词与字上的效果（点亮、光晕、闪点、十字爆闪、径迹、追字光斑），
   * 光场、烟雾、星空、线稿、浮尘、背景歌词、主题图标、画框与片尾卡的光都不画。字的明暗仍按光束算.
   */
  textOnly: boolean;
  /** 关键字着色（主题 wordColors）. */
  keywordColors: boolean;
  /** 主题图标（主题 lyricsIcons 画成线稿）. */
  themeIcons: boolean;
  /** 主题色占比, 0..1：0 = 香槟金光；越高光色越接近强调色、点亮 / 未唱的字越接近主色 / 次色. */
  themeColorMix: number;
  /** 画质. */
  renderQuality: LumiereRenderQuality;
}

export const DEFAULT_LUMIERE_TUNING: LumiereTuning = {
  render: { scale: 'global', antialias: 'global' },
  lightIntensity: 1,
  audioResponse: 1,
  fogDensity: 1,
  darkField: 0.75,
  moteAmount: 1,
  bloom: 1,
  textBloom: 1,
  unlitOpacity: 0.22,
  windowNeighbors: 2,
  decay: 1,
  echo: 1,
  fogOctaves: 5,
  lineArt: true,
  frontBokeh: true,
  trails: true,
  hideTrails: false,
  seamlessTransitions: true,
  overlayFrame: true,
  textOnly: false,
  keywordColors: true,
  themeIcons: true,
  themeColorMix: 0.3,
  renderQuality: 'full',
};

// Diorama's camera STYLE (calm/standard/chaotic) is not part of its tuning: like every other
// visualizer it follows theme.animationIntensity (the player-panel intensity chip / AI themes), so
// the theme system stays the single source of truth. The tuning only carries diorama-specific knobs.
/** The two mutually-exclusive shapes the point-cloud layer can take. */
export type DioramaGeometryMode = 'clouds' | 'corridor';

export interface DioramaGeometryVisibility {
  /** Parent switch: hides the whole point-cloud layer without discarding child preferences. */
  enabled: boolean;
  /**
   * 'clouds' = per-lyric point-cloud formations (the family switches below apply).
   * 'corridor' = one always-on point tunnel threaded along the flight path (families ignored).
   * The two never render together - picking one replaces the other.
   */
  mode: DioramaGeometryMode;
  /** Point-cloud cubes used by architectural formations. */
  strands: boolean;
  /** Open cylindrical point-cloud shells. */
  blobs: boolean;
  /** Triangular tetrahedron point-cloud crystals. */
  ribbons: boolean;
  /** Circular point-cloud loops. */
  rings: boolean;
}

export const DEFAULT_DIORAMA_GEOMETRY_VISIBILITY: DioramaGeometryVisibility = {
  enabled: true,
  mode: 'clouds',
  strands: true,
  blobs: true,
  ribbons: true,
  rings: true,
};

export const DIORAMA_PARTICLE_DENSITY_MIN = 96;
export const DIORAMA_PARTICLE_DENSITY_MAX = 1536;
export const DIORAMA_PARTICLE_DENSITY_STEP = 24;
// Background dust motes PER LINE of the resident window (see dioramaMoteField.ts). The motes sit in a
// shell around the flight axis, and the two axes are INDEPENDENT: 圆周 = motes around each ring, 径向 =
// how many layers across the shell's thickness (inner→outer). Motes-per-line = 圆周 x 径向; the window
// holds 8 lines, so MAX x MAX bounds the layer at 8*48*4 = 1536 points for low-end GPUs / OBS sources
// however far the sliders are dragged. Default 28 x 2 = 56 matches the old single-slider default.
export const DIORAMA_MOTE_CIRCUMFERENCE_MIN = 4;
export const DIORAMA_MOTE_CIRCUMFERENCE_MAX = 48;
export const DIORAMA_MOTE_CIRCUMFERENCE_STEP = 2;
export const DIORAMA_MOTE_RADIAL_MIN = 1;
export const DIORAMA_MOTE_RADIAL_MAX = 4;
export const DIORAMA_MOTE_RADIAL_STEP = 1;
export const DIORAMA_PARTICLE_SCALE_MIN = 0.65;
export const DIORAMA_PARTICLE_SCALE_MAX = 1.6;
export const DIORAMA_PARTICLE_SCALE_STEP = 0.05;
// Compatibility aliases for the uncommitted tuning UI while it migrates from point size to cluster scale.
export const DIORAMA_PARTICLE_SIZE_MIN = DIORAMA_PARTICLE_SCALE_MIN;
export const DIORAMA_PARTICLE_SIZE_MAX = DIORAMA_PARTICLE_SCALE_MAX;
export const DIORAMA_PARTICLE_SIZE_STEP = DIORAMA_PARTICLE_SCALE_STEP;
export const DIORAMA_PARTICLE_GLOW_INTENSITY_MIN = 0.1;
export const DIORAMA_PARTICLE_GLOW_INTENSITY_MAX = 1.5;
export const DIORAMA_PARTICLE_GLOW_INTENSITY_STEP = 0.05;

export interface DioramaTuning {
  /** 分辨率与抗锯齿（#929）：默认跟随「动画与性能」里的全局挡位（utils/lyricRenderQuality.ts）。 */
  render: LyricRenderOverride;
  cameraSpeed: number;
  motionAmount: number;
  audioReactivity: number;
  geometryVisibility: DioramaGeometryVisibility;
  /** Number of points requested for each formation anchor; the renderer also enforces a global cap. */
  particleDensity: number;
  /** Spatial scale multiplier for each complete point-cloud formation. */
  particleScale: number;
  /** One soft gradient aura per point-cloud cluster, separate from lyric sung-glow. */
  particleGlowEnabled: boolean;
  particleGlowIntensity: number;
  showParticles: boolean;
  /** Background dust shell, two INDEPENDENT axes (motes-per-line = the product; field clamps to its cap):
   *  背景粒子·圆周密度 = motes around each ring, 背景粒子·径向密度 = layers across the shell thickness. */
  backgroundParticleCircumference: number;
  backgroundParticleRadial: number;
  /** 普通辉光跟唱: soft glow on the unit being sung. Independent toggle + strength. */
  glowEnabled: boolean;
  glowIntensity: number;
  /** 灵魂出窍跟唱: a ghost copy of the sung glyph drifts out of the text. Independent toggle + strength. */
  soulEnabled: boolean;
  soulIntensity: number;
  /** 当前字漂移: a plain ON/OFF sub-switch of 灵魂出窍. ON lets the glyph CURRENTLY being sung drift at the
   *  same 灵魂出窍强度 as every other glyph; OFF holds it perfectly registered (no doubling / reading
   *  obstruction) until it finishes, after which it detaches and flies like the rest. No strength of its
   *  own - it borrows soulIntensity. Only has a visible effect when soulEnabled. */
  soulActiveEnabled: boolean;
  /** 渐变跟唱: the line's fill progressively deepens with the sung progress. Independent toggle + strength. */
  gradientEnabled: boolean;
  gradientIntensity: number;
  /** 关键字着色: the theme's `wordColors` keywords (written by the AI theme from the song's lyrics) become
   *  the follow-sing TARGET colour of the units they cover - hidden until the singing reaches them, never
   *  a resting colour. Same source and matcher as every other visualizer. */
  keywordColoringEnabled: boolean;
}

export const DEFAULT_DIORAMA_TUNING: DioramaTuning = {
  render: { scale: 'global', antialias: 'global' },
  cameraSpeed: 1,
  motionAmount: 1,
  audioReactivity: 1,
  geometryVisibility: DEFAULT_DIORAMA_GEOMETRY_VISIBILITY,
  particleDensity: 576,
  particleScale: 1,
  particleGlowEnabled: true,
  particleGlowIntensity: 0.65,
  showParticles: true,
  backgroundParticleCircumference: 28,
  backgroundParticleRadial: 2,
  glowEnabled: true,
  glowIntensity: 1,
  soulEnabled: true,
  soulIntensity: 1,
  soulActiveEnabled: false,
  gradientEnabled: false,
  gradientIntensity: 1,
  keywordColoringEnabled: true,
};

export type MonetBackgroundSource = 'cover-derived' | 'uploaded-global';
export type MonetBackgroundLayout = 'full-overlay' | 'half-pane-gradient';
export type MonetBackgroundWashColorMode = 'theme' | 'custom';
export type NomandBackgroundSource = 'cover-derived' | 'uploaded-global';
export type NomandBackgroundDitheringType = '2x2' | '4x4' | '8x8';
export type NomandBackgroundEffect = 'dithering' | 'fluted-glass' | 'paper-texture' | 'halftone-dots' | 'lens-distortion';
export type LatentBackgroundDisplayMode = 'dithering' | 'mesh' | 'both';
export type LatentBackgroundColorSource = 'cover-theme' | 'cover-only';
export type MonetAudioStyle = 'bar' | 'line';
// 'none' 不显示肖像，只留歌词（#1124）。
export type MonetPortraitSource = 'cover' | 'custom' | 'none';
// 莫奈的歌曲描述和封面拖动按钮：鼠标移上去才出现（原来的样子）、一直显示、不显示。
export type MonetChromeVisibility = 'auto' | 'always' | 'hidden';
export const MONET_CHROME_VISIBILITIES: readonly MonetChromeVisibility[] = ['auto', 'always', 'hidden'];
export type BuiltinVisualizerBackgroundMode = 'common' | 'monet' | 'nomand' | 'latent' | 'url' | 'sora' | 'particles' | 'sonic' | 'mv';
export type VisualizerBackgroundMode = BuiltinVisualizerBackgroundMode | (string & {});

export interface UrlBackgroundItem {
  id: string;
  url: string;
  note: string;
}

export interface MonetBackgroundTuning {
  backgroundSource: MonetBackgroundSource;
  /**
   * 背景里要不要画那张图（封面派生图 / 上传的图）。
   *
   * 关掉就只剩渐变底与纹理：有人只想借莫奈的配色，不想看见封面本身；
   * 也方便在封面画质差的时候直接藏起来。不影响 `backgroundSource` 的取值，
   * 所以再打开还是原来那张。
   */
  backgroundShowCover: boolean;
  backgroundLayout: MonetBackgroundLayout;
  backgroundBlurPx: number;
  backgroundOverlayOpacity: number;
  backgroundGrayscale: number;
  backgroundSaturation: number;
  backgroundWash: number;
  backgroundHalfPaneOffsetX: number;
  backgroundWashColorMode: MonetBackgroundWashColorMode;
  backgroundWashCustomColor: string;
  /** 整张背景图的缓慢缩放漂移；纯 CSS 合成层动画，不参与背景烘焙。 */
  backgroundDriftEnabled: boolean;
  /** 漂移幅度 0..1，同时决定位移距离和为防止露边而预放大的倍率。 */
  backgroundDriftStrength: number;
  /** 是否在烘焙的 overlay 里绘制那几条 1px 竖向纹理。 */
  backgroundStreaksEnabled: boolean;
}

export interface NomandBackgroundTuning {
  imageSource: NomandBackgroundSource;
  effect: NomandBackgroundEffect;
  ditheringType: NomandBackgroundDitheringType;
  size: number;
  colorSteps: number;
  originalColors: boolean;
  inverted: boolean;
  flutedGlassSize: number;
  flutedGlassDistortion: number;
  flutedGlassBlur: number;
  paperTextureContrast: number;
  paperTextureRoughness: number;
  paperTextureFiber: number;
  halftoneDotsSize: number;
  halftoneDotsRadius: number;
  halftoneDotsContrast: number;
  halftoneDotsOriginalColors: boolean;
  halftoneDotsInverted: boolean;
  lensDistortionSpread: number;
  lensDistortionBulge: number;
  lensDistortionDispersion: number;
  overlayEnabled: boolean;
  overlayOpacity: number;
}

export interface LatentBackgroundTuning {
  displayMode: LatentBackgroundDisplayMode;
  colorSource: LatentBackgroundColorSource;
  dynamicOnlyInPlayer: boolean;
  enhancedBeatResponse: boolean;
  ditheringSpeed: number;
  ditheringAudioSpeed: number;
  ditheringSize: number;
  ditheringOpacity: number;
  meshSpeed: number;
  meshAudioSpeed: number;
  meshDistortion: number;
  meshSwirl: number;
  overlayEnabled: boolean;
  overlayOpacity: number;
}

export interface SoraBackgroundTuning {
  /** Skips the WebGL starfield and shows a static solid black (night) / white (daylight) frame. */
  blank: boolean;
}

/**
 * 粒子背景（从 Mineradio 的封面粒子搬来）的可调项。
 *
 * 只列着色器真的实现了的：Mineradio 那边的 bloom / scatter / twist 在我们这套
 * 单 pass 渲染里没有对应物，所以不在这里出现 —— 暴露一个不生效的滑条更糟。
 */
export interface ParticlesBackgroundTuning {
  /**
   * 形态：同一套粒子几何的几种排布。
   *
   * auto 自动（按歌挑一种）· silk 丝绸（专辑封面）· tunnel 滚筒 ·
   * planet 星球 · vinyl 唱片。
   * 这几个在 Mineradio 里是同一个着色器的几个 preset 分支。
   */
  form: 'auto' | 'silk' | 'tunnel' | 'planet' | 'vinyl';
  /** 每边的格数。越大越细腻，也越吃性能；96 是调好的默认值。 */
  grid: number;
  /** 整体强度，乘在频段与尺寸上。1 为标定值。 */
  intensity: number;
  /** 单个粒子的大小倍数。 */
  pointScale: number;
  /** 主题色染色的强度，0 是完全用封面本身的颜色。 */
  tintStrength: number;
  /** 是否随低频自动打涟漪（关掉后只有鼓点爆裂会推一下）。 */
  autoRipple: boolean;
}

export const DEFAULT_PARTICLES_BACKGROUND_TUNING: ParticlesBackgroundTuning = {
  /*
   * 默认「自动」：按歌挑一种形态（同一首歌总是同一种，换歌才换）。
   * 用户不用先去设置里选，看几天下来也不会腻。
   */
  form: 'auto',
  grid: 96,
  intensity: 1,
  pointScale: 1,
  tintStrength: 1,
  autoRipple: true,
};

/**
 * 音域回响背景（从 Mineradio 的 sonic-topography-preset 搬来）的可调项。
 *
 * 那边的旋钮全是 0..100 的整数（sonicGround*），这里保持同样的取值域，
 * 默认值直接照抄，不用换算。8 个频段 EQ 与配色不外露 —— 那几个需要
 * 调音知识才知道怎么调，默认值就能直接用。
 */
export interface SonicBackgroundTuning {
  /** 地形密度：决定每边多少根柱子（平方增长，所以上限卡在 100）。 */
  density: number;
  /** 起伏幅度。50 是标定值，往上按平方放大。 */
  amplitude: number;
  /** 地面范围。越大铺得越开。 */
  range: number;
  /** 垂直位置。越大压得越低。 */
  lower: number;
  /** 景深：地形往后推多远。 */
  depth: number;
  /** 发光强度。 */
  glow: number;
  /** 平滑度：静息起伏更偏噪声（低）还是更偏波纹（高）。 */
  smoothness: number;
  /** 锐利度：柱子侧面阴影的陡峭程度。 */
  sharpness: number;
}

export const DEFAULT_SONIC_BACKGROUND_TUNING: SonicBackgroundTuning = {
  density: 46,
  amplitude: 50,
  range: 82,
  lower: 68,
  depth: 62,
  glow: 68,
  smoothness: 50,
  sharpness: 50,
};

export interface MonetTuning {
  /** 分辨率与抗锯齿（#929）：默认跟随「动画与性能」里的全局挡位（utils/lyricRenderQuality.ts）。 */
  render: LyricRenderOverride;
  keywordColoringEnabled: boolean;
  /** Whether the description shows at all; kept equal to `descriptionVisibility !== 'hidden'` for older readers. */
  showDescription: boolean;
  /** How the song description shows. Older tunings have only `showDescription`: on is 'auto'. */
  descriptionVisibility?: MonetChromeVisibility;
  showAudioVisualization: boolean;
  audioStyle: MonetAudioStyle;
  fontScale: number;
  portraitSource: MonetPortraitSource;
  portraitOffsetX?: number;
  portraitStyle?: 'square' | 'rectangular';
  /** Whether the drag handle shows at all; kept equal to `portraitHangerVisibility !== 'hidden'` for older readers. */
  showPortraitDragHanger?: boolean;
  /** How the portrait's drag handle shows. Older tunings have only `showPortraitDragHanger`: on is 'auto'. */
  portraitHangerVisibility?: MonetChromeVisibility;
  /** 歌词左右镜像（#1124）：肖像在左、文字靠右排，整个画面左右对称。 */
  mirrorLayout?: boolean;
  /** 自定义的歌曲描述；空着就显示主题自带的描述。 */
  customDescription?: string;
}

export const DEFAULT_MONET_BACKGROUND_TUNING: MonetBackgroundTuning = {
  backgroundSource: 'cover-derived',
  backgroundShowCover: true,
  backgroundLayout: 'full-overlay',
  backgroundBlurPx: 6,
  backgroundOverlayOpacity: 0.74,
  backgroundGrayscale: 0,
  backgroundSaturation: 1.05,
  backgroundWash: 0.34,
  backgroundHalfPaneOffsetX: 0,
  backgroundWashColorMode: 'theme',
  backgroundWashCustomColor: '#8fb7ff',
  backgroundDriftEnabled: true,
  backgroundDriftStrength: 0.5,
  backgroundStreaksEnabled: true,
};

export const DEFAULT_NOMAND_BACKGROUND_TUNING: NomandBackgroundTuning = {
  imageSource: 'cover-derived',
  effect: 'dithering',
  ditheringType: '8x8',
  size: 3,
  colorSteps: 4,
  originalColors: false,
  inverted: false,
  flutedGlassSize: 0.5,
  flutedGlassDistortion: 0.5,
  flutedGlassBlur: 0.08,
  paperTextureContrast: 0.32,
  paperTextureRoughness: 0.42,
  paperTextureFiber: 0.3,
  halftoneDotsSize: 0.5,
  halftoneDotsRadius: 1.25,
  halftoneDotsContrast: 0.4,
  halftoneDotsOriginalColors: false,
  halftoneDotsInverted: false,
  lensDistortionSpread: 0.45,
  lensDistortionBulge: 0.3,
  lensDistortionDispersion: 0.65,
  overlayEnabled: true,
  overlayOpacity: 0.35,
};

export const DEFAULT_LATENT_BACKGROUND_TUNING: LatentBackgroundTuning = {
  displayMode: 'both',
  colorSource: 'cover-theme',
  dynamicOnlyInPlayer: true,
  enhancedBeatResponse: true,
  ditheringSpeed: 0.1,
  ditheringAudioSpeed: 1.2,
  ditheringSize: 2.5,
  ditheringOpacity: 0.55,
  meshSpeed: 0.3,
  meshAudioSpeed: 2,
  meshDistortion: 0.8,
  meshSwirl: 0.1,
  overlayEnabled: true,
  overlayOpacity: 0.35,
};

export const DEFAULT_SORA_BACKGROUND_TUNING: SoraBackgroundTuning = {
  blank: false,
};

export const DEFAULT_MONET_TUNING: MonetTuning = {
  render: { scale: 'global', antialias: 'global' },
  keywordColoringEnabled: true,
  showDescription: true,
  descriptionVisibility: 'auto',
  showAudioVisualization: true,
  audioStyle: 'bar',
  fontScale: 1.2,
  portraitSource: 'cover',
  portraitOffsetX: 0,
  portraitStyle: 'square',
  showPortraitDragHanger: true,
  portraitHangerVisibility: 'auto',
  mirrorLayout: false,
  customDescription: '',
};

export interface StoredCappellaEmojiImage {
  id: string;
  name: string;
  mimeType: string;
  blob: Blob;
}

export interface CappellaEmojiImage {
  id: string;
  name: string;
  url: string;
}

export interface StoredCappellaAvatarImage {
  id: string;
  name: string;
  mimeType: string;
  blob: Blob;
}

export interface CappellaAvatarImage {
  id: string;
  name: string;
  url: string;
}

export interface StoredMonetBackgroundImage {
  id: string;
  name: string;
  mimeType: string;
  blob: Blob;
}

export interface MonetBackgroundImage {
  id: string;
  name: string;
  url: string;
}

export interface StoredMonetPortraitImage {
  id: string;
  name: string;
  mimeType: string;
  blob: Blob;
}

export interface MonetPortraitImage {
  id: string;
  name: string;
  url: string;
}

export enum PlayerState {
  IDLE = 'IDLE',
  PLAYING = 'PLAYING',
  PAUSED = 'PAUSED',
}

export interface StatusMessage {
  /** Shows a decorative loader beside the visible status text. */
  activity?: 'loading' | 'success' | 'error';
  /** Keeps one loader mounted while its strokes morph into the result. */
  activityId?: number;
  type: 'error' | 'success' | 'info';
  text: string;
  /** A second line under the text: what to do about it. */
  note?: string;
  /** Words quoted from outside the app (a platform's own answer), with their code. */
  quote?: { text: string; code?: string };
  /** A count down to the action happening on its own (the skip to the next song): its line ("5 秒后跳到下一首"),
   *  the whole seconds left and the whole time, so the action button fills over it without stepping. Kept out
   *  of `text` so the toast stays the same one while it counts. */
  countdown?: { text: string; seconds: number; totalMs: number };
  /** The online platform the message is about: its mark stands before the text, in place of the type's icon. */
  providerId?: OnlineProviderId;
  /**
   * 这条提示**不吃点击**（提示条默认是 `pointer-events: auto`，会浮在可视化那一层上面，
   * 把点击接走）。给「点一下空白 → 弹提示 → 再点一下任意处」这种用法用：不然用户补的
   * 那一下落在提示条上，就永远到不了下面那一层，于是只能反复弹同一句提示。
   */
  inert?: boolean;
  nonce?: number;
  durationMs?: number;
  actionLabel?: string;
  /** Icon drawn before actionLabel inside the action button. */
  actionIcon?: LucideIcon;
  onAction?: () => void;
  cancelLabel?: string;
  onCancel?: () => void;
  persistent?: boolean;
}

// Search API Types

export interface Artist {
  id: MediaId;
  name: string;
  entityId?: string;
  catalogRef?: ProviderCatalogRef;
}

export interface Album {
  id: MediaId;
  name: string;
  coverUrl?: string;
  entityId?: string;
  catalogRef?: ProviderCatalogRef;
}

export interface SongPrivilege {
  id?: number;
  fee?: number;
  payed?: number;
  st?: number;
  pl?: number;
  dl?: number;
  flag?: number;
  cs?: boolean;
}

export interface NoCopyrightRecommendation {
  type?: number;
  typeDesc?: string;
  songId?: string | number;
  thirdPartySong?: unknown | null;
  expInfo?: unknown | null;
}

// The names of the lyric sources, read off the table in utils/lyrics/lyricSources.ts.
export type { LyricProviderSource };

/**
 * 设置里存的那一项：可以是一个具体平台，也可以是「跟随播放平台来源」。
 *
 * 两层不是多此一举 —— 具体平台才能发请求，而「跟随」要等拿到歌才知道是哪个平台，
 * 所以每个消费点传 preferredSource 之前都要过 resolveLyricSourcePreference 解析一次。
 */
export type LyricSourcePreference = LyricProviderSource | 'follow-source';
export type AmllDbPlatform = 'ncm' | 'qq';

export interface ReplayGainInfo {
  /** ReplayGain gain values in decibels. */
  trackGain?: number;
  albumGain?: number;
  /** ReplayGain peak values as positive linear ratios. */
  trackPeak?: number;
  albumPeak?: number;
}

export interface SongResult {
  id: MediaId;
  name: string;
  artists: Artist[];
  album: Album;
  durationMs: number;
  isPureMusic?: boolean;
  aliases?: string[];
  translatedNames?: string[];
  t?: 0 | 1 | 2;
  sourceType?: 'netease' | 'cloud';
  sourceRef?: PlaybackSourceRef;
  /** Identity of the concrete bytes selected for playback; used to reject stale derived media. */
  playbackSourceRevision?: string;
  fee?: number;
  // Its audio is a music video's, which may hold an intro, a scene or another mix: rows tag it MV.
  isVideo?: boolean;
  noCopyrightRcmd?: NoCopyrightRecommendation | null;
  resourceState?: boolean;
  privilege?: SongPrivilege;
  onlineLyricsState?: OnlineLyricsState;
  matchedLyricsSource?: LyricProviderSource;
  matchedLyricsProviderPlatform?: AmllDbPlatform;
  replayGain?: ReplayGainInfo;
  qqMid?: string;
  kgHash?: string;
  amllDbPlatform?: AmllDbPlatform;
  /**
   * 云端缓存里那条主题键 —— 只有从「AI 主题」那一屏（云端歌名清单）挑出来的歌才有。
   *
   * 点了播放要用 *直接用上云上那一条*，而不是再生成一遍：生成要有歌词、要花 API Key，
   * 而这条缓存存在的意义就是不必再算一次。见 services/aiThemeCloud.ts。
   */
  aiCloudThemeKey?: string;
}
export interface OnlineLyricsState {
  lyricsSource: 'online' | 'imported';
  importedLyrics?: LyricData | null;
  importedLyricsName?: string | null;
  hasOnlineOverride?: boolean;
  onlineOverrideLyrics?: LyricData | null;
  matchedSongId?: MediaId;
  matchedIsPureMusic?: boolean;
  matchedLyricsSource?: LyricProviderSource;
  matchedLyricsProviderPlatform?: AmllDbPlatform;
}

export interface SearchResponse {
  result?: {
    songs?: SongResult[];
    songCount?: number;
  };
  code: number;
}

// Local Music Types

export type LocalLyricsPriority = 'local' | 'online';
export type ActiveLocalLyricsSource = 'local' | 'embedded' | 'online';
// Where a local song's `local*LyricsContent` came from: a sidecar file picked by the import, or a
// file the user uploaded from the panel. Records written before this field existed have none.
export type LocalLyricsOrigin = 'sidecar' | 'upload';

export interface LocalSong {
  id: string; // UUID for local file
  fileName: string;
  filePath: string; // File path for reference
  fileHandle?: FileSystemFileHandle; // For re-accessing the file (not persisted, stored in memory)
  /**
   * 安卓原生曲库的音频标识（MediaStore 的 id，或导入时写进私有目录的文件名）。
   *
   * 不存播放 URL：那个地址是原生临时起的小服务（端口每次启动都可能变），
   * 存下来重启就失效。播放前用它按当前端口重新拼（见 nativeAudioUrlForRef）。
   */
  nativeAudioRef?: string;
  duration: number; // milliseconds
  fileSize: number; // bytes
  fileLastModified?: number; // milliseconds since epoch
  fileSignature?: string; // Lightweight file identity for incremental scans
  mimeType: string;
  bitrate?: number; // bps
  addedAt: number; // timestamp

  // Canonical metadata and retained source snapshots
  title: string;
  titleOrigin: import('./types/localLibrary').LocalSongTitleOrigin;
  importedMetadata: import('./types/localLibrary').LocalSongImportedMetadata;
  onlineMetadata?: import('./types/localLibrary').LocalSongOnlineMetadata;
  trackNumber?: number;
  discNumber?: number;
  embeddedMetadataVersion?: number;

  localCoverAssetId?: string; // Content-addressed preferred local cover stored in local_cover_assets
  localCoverSource?: import('./types/localCover').LocalCoverSourceKind;
  localCoverNeedsAssetMigration?: boolean; // Retries local cover hashing/persistence during the next rescan
  replayGain?: number; // ReplayGain track gain in dB
  replayGainTrackGain?: number; // ReplayGain track gain in dB
  replayGainTrackPeak?: number; // ReplayGain track peak ratio
  replayGainAlbumGain?: number; // ReplayGain album gain in dB
  replayGainAlbumPeak?: number; // ReplayGain album peak ratio

  // Lyrics matching result
  matchedLyrics?: LyricData;
  matchedIsPureMusic?: boolean;
  matchedLyricsSongId?: number | string; // Provider-scoped ID used for the saved lyric result
  hasManualLyricSelection?: boolean;
  markedPureMusic?: boolean; // User marked the song as instrumental: automatic lyric matching never runs for it
  folderName?: string; // Name of the folder if imported via folder import
  noAutoMatch?: boolean; // If true, do not attempt to auto-match metadata
  matchedLyricsSource?: LyricProviderSource;
  matchedLyricsProviderPlatform?: AmllDbPlatform;

  // User preferences for online data override (set via LocalSongLyricMatch)
  lyricsSource?: 'local' | 'embedded' | 'online';  // Explicit lyrics source selection; undefined = the configured automatic priority
  useOnlineCover?: boolean;     // Prefer online cover over embedded cover

  // Local Lyrics (.lrc / .vtt / .ttml / .qrc / .yrc / .krc files)
  hasLocalLyrics?: boolean;
  localLyricsContent?: string;
  localLyricsFormat?: 'vtt' | 'ttml' | 'yrc' | 'qrc' | 'krc';
  localLyricsOrigin?: LocalLyricsOrigin;
  hasLocalTranslationLyrics?: boolean;
  localTranslationLyricsContent?: string;
  localTranslationLyricsOrigin?: LocalLyricsOrigin;

  // Embedded Lyrics (from file tags: ID3 USLT, Vorbis LYRICS, etc.)
  hasEmbeddedLyrics?: boolean;
  embeddedLyricsContent?: string;
  hasEmbeddedTranslationLyrics?: boolean;
  embeddedTranslationLyricsContent?: string;
}

export interface LocalLibrarySnapshotFile {
  name: string;
  relativePath: string;
  kind: 'audio' | 'lyric' | 'translationLyric' | 'cover' | 'other';
  size: number;
  lastModified: number;
  signature: string;
}

export interface LocalLibrarySnapshotNode {
  name: string;
  ignored?: boolean;
  relativePath: string;
  hash: string;
  files: LocalLibrarySnapshotFile[];
  children: LocalLibrarySnapshotNode[];
}

export interface LocalLibrarySnapshot {
  rootFolderName: string;
  /**
   * 「删除文件夹」留下的墓碑。
   *
   * 删根目录只删掉了库里的歌，而**刷新**在安卓上等于整库重扫一次（resyncAllFolders →
   * scanAndroidDeviceMusic），歌会被原样扫回来 —— 于是「删了、一刷新又回来了」。
   * 所以删根时留一条记录：刷新那条路照它跳过，只有用户**显式**点「扫描设备音乐」才清掉。
   */
  rootRemoved?: boolean;
  ignoredFolderPaths?: string[];
  lyricFormatOrder?: import('./utils/lyrics/localLyricFormatOrder').LocalLyricFileFormat[]; // Sidecar lyric format order this scan used; undefined = default order
  scannedAt: number;
  tree: LocalLibrarySnapshotNode;
}

export interface LocalPlaylist {
  id: string;
  name: string;
  songIds: string[];
  createdAt: number;
  updatedAt: number;
  isFavorite?: boolean;
}

export type LocalLibraryGroupType = 'folder' | 'album' | 'artist' | 'playlist';

export interface LocalLibraryGroup {
  type: LocalLibraryGroupType;
  name: string;
  songs: LocalSong[];
  coverUrl?: string | Blob;
  id: string;
  isVirtual?: boolean;
  trackCount?: number;
  description?: string;
  albumId?: number;
  entityId?: string;
  playlistId?: string;
}

export type {
  LocalLibraryAssignment,
  LocalLibraryAssignmentOrigin,
  LocalLibraryEntity,
  LocalLibraryEntityKind,
  LocalSongImportedMetadata,
  LocalSongMetadataSource,
  LocalSongOnlineMetadata,
  LocalSongReference,
  LocalSongTitleOrigin,
} from './types/localLibrary';

// Extend SongResult to support local files and Navidrome files
export interface UnifiedSong extends SongResult {
  sourceRef: PlaybackSourceRef;
  // The row this song was read from, where its collection names its rows: a YouTube Music
  // playlist may hold a song twice, and a removal names the row. It says nothing of the song.
  collectionRowId?: string;
  // How many times the account played it, as its platform's listening ranking counts, where the song
  // was read from that ranking. Like collectionRowId it belongs to the row, not to the song.
  listenCount?: number;
  isLocal?: boolean;
  localRef?: import('./types/localLibrary').LocalSongReference;
  isNavidrome?: boolean;
  navidromeData?: any;
}

export type ReplayGainMode = 'off' | 'track' | 'album' | 'auto';

// Audio Analysis Types
import { MotionValue } from 'framer-motion';

export interface AudioBands {
    bass: MotionValue<number>;    // 20-150Hz (Circles)
    lowMid: MotionValue<number>;  // 150-400Hz (Squares)
    mid: MotionValue<number>;     // 400-1200Hz (Triangles)
    vocal: MotionValue<number>;   // 1000-3500Hz (Icons)
    treble: MotionValue<number>;  // 3500Hz+ (Crosses)
    spectrum?: MotionValue<Uint8Array<ArrayBuffer>>; // Raw analyser FFT magnitude bins for full-spectrum visualizers
  }
